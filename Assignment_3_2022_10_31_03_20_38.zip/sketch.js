let x, y;
let mainsprite,spr1,spr2, bouncy;
let bouncecircle = [];
let dance1
let dance2
let dance3






var r = 0
var g = 0
var pigsound
var bmusic
var coins
var score = 0;






function preload(){
  pigsound = loadSound("pigsound.wav");
  bmusic = loadSound("bamusic.mov");
  pigimage= loadImage ("pig.png");
}




function setup() {
  createCanvas(620, 600);
  bmusic.play();



 
  x =  random (width) ;
  y =  random (height);
  
  
  mainsprite = new Sprite();
  mainsprite.diameter = 50;
  mainsprite.shapeColor = color('white')
  
  
  spr1 = createSprite(width/2, height/2, 120);
  spr1.shapeColor = color('red')



 
  spr2 = createSprite(width/2, height/2, 50);




  spr3 = createSprite(width/2,height/2, 200);



 
  bouncy = new Group();
  bouncy.color = 'blue';
  
  for (let i = 0; i < 20; i++) {
        new bouncy.Sprite(i * 20, random, 70);
    }
  
  coins = new Group();
  for (var i = 0; i < 20; i++) {
    var c= createSprite(random(100, width-100), random(100,         height-100),20);
    c.addImage('normal',pigimage);
    c.scale = 0.2;
    
    c.shapeColor = color(255, 255, 0);
    coins.add(c);
  }
  
  
  dance1 = new Jitter();
  dance2 = new Jitter();
  dance3 = new Jitter();
  
  
  
  
  
}



function draw() {
  background('rgba(0,925,110,.72)');
  background(r, g);
  r = map(mouseX, 20, 400, 40, 25)
  g = map(mouseX, 20, 400, 45, 20)
  
for (let i = 0; i < allSprites.length; i++) {
  



   if (allSprites[i].position.y > height) {
      allSprites[i].velocity.y *= -.8;
      
    }
   if (allSprites[i].position.y < 0) {
      allSprites[i].velocity.y *= -.8;
      
    }
  
    if (allSprites[i].position.x > width){
      allSprites[i].velocity.x *= -.8;
    }
  
    if (allSprites[i].position.x < 0){
      allSprites[i].velocity.x *= -.8;
    }



}
  
  mainsprite.velocity.x = (mouseX-mainsprite.position.x)*0.1;
  mainsprite.velocity.y = (mouseY-mainsprite.position.y)*0.1;





 



 stroke(90);
  fill (100,140,300,240);
  ellipse(x, y, 94, 94);
  
  
  dance1.move();
  dance1.display();
  dance2.move();
  dance2.display();
  dance3.move();
  dance3.display();
  
  spr1.overlap(coins, getCoin);



 
  
  drawSprites();
  



 
  
}



function getCoin(player, coin) {
  coin.remove();
  pigsound.play();
}



class Jitter {
  constructor() {
    this.x = random(width);
    this.y = random(height);
    this.diameter = random(40, 140);
    this.speed = 0.3;
  }







move() {
    this.x += random(-this.speed, this.speed);
    this.y += random(-this.speed, this.speed);
  }







display() {
    ellipse(this.x, this.y, this.diameter, this.diameter);
  }
}